MEINE FUSSBALLKARRIERE – SPIELVERSION 1.0

1. ZIP entpacken.
2. index.html öffnen.
3. Spielen. Der Spielstand wird automatisch im Browser gespeichert.

Die Version enthält ein komplettes lokales Gameplay:
Karriere, Spiele, Training, Transfers, Vertragsangebote, Geld, Privatleben,
Immobilien, Autos, Investments, Entscheidungen, Verletzungen, Statistiken,
Nachrichten und Karriereende.

Für eine echte Veröffentlichung folgen später Backend, Accounts, native
Android/iOS Builds, Store-Material, Datenschutz/Impressum und Lizenzprüfung.
